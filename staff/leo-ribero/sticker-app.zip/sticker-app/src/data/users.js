db.users = [
	new User('Pepito Grillo', 'pepito', '123123123'),
	new User('Peter Pan', 'peter', '123123123'),
	new User('Wendy Bread', 'wendy', '123123123')
]