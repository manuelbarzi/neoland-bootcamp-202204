 db.notes = [
    new Note('wendy', 'Happy Flower!'),
    new Note('wendy', 'Hellow World!'),
    new Note('pepito', 'Hola, Mundo'),
    new Note('peter', 'Who the f**** is Pepito!??????')
]

// ahora hay que crear la logica para cuando creamos la nota
// aún no existe y vamos a hacer un logic/createNote