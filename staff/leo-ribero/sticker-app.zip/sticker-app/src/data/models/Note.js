function Note(username, text){
    //this.id = queda para luego
    this.username = username
    this.text = text
    this.date = new Date
}