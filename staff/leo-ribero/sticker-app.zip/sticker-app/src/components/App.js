function App() {
	Component.call(this, `<main class="App"></main>`)
}

chainPrototypes(Component, App)